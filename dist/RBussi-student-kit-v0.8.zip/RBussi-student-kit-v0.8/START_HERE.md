# RBussi Student Kit — v0.8

Extract this ZIP before opening its files. Start with [the setup guide](docs/student-setup.md).

In class: install Thonny during the 30-minute setup block, connect the ESP32, install or verify the supplied MicroPython firmware, and upload `robot.py` to the board.

Run `examples/00_check_setup.py` first; it requests no movement. Then use `examples/first_drive.py` with wheels lifted and the motor battery connected. Save personal programs under a new filename on your computer.

- [Firmware installation and library upload](docs/firmware-and-library.md)
- [Movement API](docs/quick-reference.md)
- [Library guide and examples](docs/library.md)
- [Wheel balance and calibration](docs/wheel-calibration.md)
- [Wiring reference and voltage check](docs/wiring-reference.md)
- [Day 1 observation worksheet](worksheets/day01-observations.md)
- [Day 2 plan and sensor exercises](docs/day-02-plan.md)
- [Day 2 examples and settings upload](examples/day02/README.md)
- [Day 2 observation worksheet](worksheets/day02-observations.md)
- [Firmware source and license information](firmware/SOURCE.md)

Baseline: Thonny 5.0.0, MicroPython 1.29.0, classic ESP32 Wemos D1 R32, class `RBussi`.

The ZIP includes firmware and course files, not Thonny installers, USB drivers, simulator software, or Moodle credentials. Get the actual course and simulator links from the instructor. Windows/macOS and student Linux installation routes still require instructor rehearsal.

`SHA256SUMS.txt` records hashes of all other kit files to detect accidental changes; it is not a signature.
