# Turtlesim background extension

Vendored from https://github.com/ros/ros_tutorials/tree/c83136eb8d0d3ed52eb0906183dd86ca309a4ed2/turtlesim (Jazzy). Original BSD 3-clause notices are retained in each source/header; see LICENSE.

Changes: fixed logical 640 × 480 field with a resizable, aspect-preserving view; optional startup-only `background_image` ROS parameter; aspect-preserving cached map drawn below trails. The local CMakeLists builds against the installed Jazzy turtlesim interfaces. Motion and service interfaces are unchanged. The colour sensor now reads a cached map/background raster at the robot centre, ignoring pen trails and teaching overlays. /sim/real_sensors can display actual robot line readings, with a stale-data label.

The separate map artwork is owned by Robotx Oy and is not covered by this software license; see ../assets/RIIHIMAKI-MAP-NOTICE.txt.

The optional `/sim/overlay` String subscription renders the teaching route and sensor dots in logical image coordinates. The overlay expires after one second without an update. Sensors are calculated by the separate `simulation/line_world.py` node; the stock turtlesim color sensor remains unchanged.
