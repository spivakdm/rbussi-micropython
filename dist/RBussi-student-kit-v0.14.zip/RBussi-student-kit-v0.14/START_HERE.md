# RBussi Student Kit — v0.14

Extract this ZIP before opening its files. Start with [the setup guide](docs/student-setup.md).

In class: install Thonny during the 30-minute setup block, connect the ESP32, install or verify the supplied MicroPython firmware, and upload `robot.py` to the board.

Day 2 needs no extra settings module: each exercise declares its own pins and parameters. Set the sensor thresholds using their trimmers and check black/white readings. Movement examples 06/08/09 use while True with no timer; stop with Ctrl+C or the motor-power switch. Examples 08/09 also stop on both-black. Optional examples 10/11 require five/three connected sensors respectively; proposed extra wiring is documented in the assignments.

Run `examples/00_check_setup.py` first; it requests no movement. Then use `examples/first_drive.py` with wheels lifted and the motor battery connected. Save personal programs under a new filename on your computer.

- [Firmware installation and library upload](docs/firmware-and-library.md)
- [Movement API](docs/quick-reference.md)
- [Library guide and examples](docs/library.md)
- [Wheel balance and calibration](docs/wheel-calibration.md)
- [Wiring reference and voltage check](docs/wiring-reference.md)
- [Day 1 observation worksheet](worksheets/day01-observations.md)
- [Day 2 plan and sensor exercises](docs/day-02-plan.md)
- [Day 2 standalone examples](examples/day02/README.md)
- [Day 3 sound, Wi-Fi and MQTT examples](examples/day03/README.md)
- [Extra tasks: five-sensor P and three-sensor relay](docs/extra-line-control-tasks.md)
- [A4 printable line templates](printables/README.md)
- [Day 2 observation worksheet](worksheets/day02-observations.md)
- [Firmware source and license information](firmware/SOURCE.md)

Baseline: Thonny 5.0.0, MicroPython 1.29.0, classic ESP32 Wemos D1 R32, class `RBussi`.

Day 3 includes MQTT/time dependencies and a public CA certificate. Copy the private settings template and fill in only your own credentials; passwords are not included. The computer terminal client requires a separate paho-mqtt installation. ESP32 network and piezo rehearsal is still required.

The ZIP includes firmware and course files, not Thonny installers, USB drivers, simulator software, or Moodle credentials. Get the actual course and simulator links from the instructor. Windows/macOS and student Linux installation routes still require instructor rehearsal.

`SHA256SUMS.txt` records hashes of all other kit files to detect accidental changes; it is not a signature.
